/* All organizations, people, inspections and checklist content below are fictional demonstration data. */
const FRS_CATEGORIES = ['Extinguisher','Hose reel','Hydrant','Fire detection','Sprinkler','Suppression'];
const FRS_TEMPLATE_NAMES = [
  ['Extinguisher','Portable extinguisher inspection'],['Extinguisher','CO2 extinguisher inspection'],['Extinguisher','Dry powder extinguisher service'],['Extinguisher','Foam extinguisher inspection'],
  ['Hose reel','Hose reel visual inspection'],['Hose reel','Hose reel functional test'],['Hose reel','Hose reel maintenance'],
  ['Hydrant','Hydrant visual inspection'],['Hydrant','Hydrant flow and pressure test'],['Hydrant','Hydrant valve maintenance'],
  ['Fire detection','Detection panel inspection'],['Fire detection','Smoke detector test'],['Fire detection','Heat detector test'],['Fire detection','Alarm device test'],
  ['Sprinkler','Sprinkler visual inspection'],['Sprinkler','Sprinkler valve inspection'],['Sprinkler','Sprinkler pump test'],
  ['Suppression','Gas suppression inspection'],['Suppression','Kitchen suppression inspection'],['Suppression','Suppression cylinder service']
];
function frsInitialData() {
  const users = [
    {id:'u1',name:'Lee Morgan',email:'lee@example.test',role:'Admin',initials:'LM',active:true},
    {id:'u2',name:'Thandi Mokoena',email:'thandi@example.test',role:'Manager',initials:'TM',active:true},
    {id:'u3',name:'Sipho Dlamini',email:'sipho@example.test',role:'Technician',initials:'SD',active:true},
    {id:'u4',name:'James Petersen',email:'james@example.test',role:'Technician',initials:'JP',active:true},
    {id:'u5',name:'Naledi Khumalo',email:'naledi@example.test',role:'Technician',initials:'NK',active:true},
    {id:'u6',name:'Daniel Jacobs',email:'daniel@example.test',role:'Technician',initials:'DJ',active:true}
  ];
  const customers = [
    {id:'c1',name:'Harbourview Logistics',contact:'A. Smith',email:'facilities@example.test',phone:'+27 21 000 0101'},
    {id:'c2',name:'Cedar Property Group',contact:'P. Botha',email:'operations@example.test',phone:'+27 11 000 0202'},
    {id:'c3',name:'Ubuntu Community Care',contact:'N. Ndlovu',email:'admin@example.test',phone:'+27 31 000 0303'}
  ];
  const sites = [
    {id:'s1',customerId:'c1',name:'Harbourview Distribution Centre',address:'12 Example Road, Cape Town',area:'Cape Town',technicianId:'u3',zones:'Warehouse A, Warehouse B, Loading bay',nextVisit:'2026-10-21'},
    {id:'s2',customerId:'c2',name:'Cedar Square Offices',address:'28 Sample Avenue, Johannesburg',area:'Johannesburg',technicianId:'u4',zones:'Ground floor, Level 1, Basement',nextVisit:'2026-10-22'},
    {id:'s3',customerId:'c3',name:'Ubuntu Care Centre',address:'5 Demo Street, Durban',area:'Durban',technicianId:'u3',zones:'Reception, Kitchen, East wing',nextVisit:'2026-10-21'},
    {id:'s4',customerId:'c1',name:'Harbourview Cold Storage',address:'8 Example Drive, Cape Town',area:'Cape Town',technicianId:'u5',zones:'Cold room, Plant room, Dispatch',nextVisit:'2026-10-23'},
    {id:'s5',customerId:'c2',name:'Cedar Industrial Park',address:'16 Sample Lane, Pretoria',area:'Pretoria',technicianId:'u6',zones:'Block A, Block B, Security',nextVisit:'2026-10-24'}
  ];
  const categoryQs = {
    'Extinguisher':['Equipment is accessible and correctly positioned','Safety pin and tamper seal are intact','Pressure indicator is within marked range','Cylinder, hose and nozzle show no visible damage','Operating instructions and identification are legible','Mounting bracket is secure'],
    'Hose reel':['Reel and hose are accessible','Hose is free of visible cracks or damage','Nozzle opens and closes correctly','Supply valve operates correctly','Reel rotates freely','No visible water leaks'],
    'Hydrant':['Hydrant is accessible and clearly identified','Body and connection show no visible damage','Caps and seals are present','Valve operates correctly','Connection is free from obstruction','No visible leaks'],
    'Fire detection':['Panel shows normal operating condition','Detector is clean and unobstructed','Device identification is legible','Test produces expected indication','Backup supply condition recorded','Device restored after test'],
    'Sprinkler':['Sprinkler heads are unobstructed','Heads and pipework show no visible damage','Control valve position recorded','Gauge condition and reading recorded','Test and drain connections are accessible','No visible leaks or corrosion'],
    'Suppression':['Cylinder is secure and accessible','Pressure or weight reading recorded','Release mechanism condition recorded','Pipework and nozzles are unobstructed','Warning signs are legible','Controls restored after inspection']
  };
  const templates = FRS_TEMPLATE_NAMES.map(([category,name],i)=>({
    id:'t'+(i+1),name,category,version:1,active:true,sample:true,updatedAt:'2026-10-19',
    questions:[...categoryQs[category].map((label,j)=>({id:'q'+(j+1),label,type:'result',required:true})),
      {id:'q7',label:'Service label / identification reference',type:'text',required:false},
      {id:'q8',label:'Additional observations',type:'text',required:false}]
  }));
  const areas=['Reception','Warehouse A','Loading bay','Ground floor','Plant room','East wing','Kitchen','Level 1'];
  const models=['9 kg dry powder','30 m hose reel','65 mm hydrant','Addressable smoke detector','Pendant sprinkler head','Suppression cylinder'];
  const assets = Array.from({length:48},(_,i)=>{
    const c=i%6,s=sites[i%sites.length];
    return {id:'FRS-'+String(i+1).padStart(4,'0'),qrToken:'FRS-ASSET-'+String(i+1).padStart(6,'0'),name:models[c],category:FRS_CATEGORIES[c],siteId:s.id,area:areas[i%areas.length],serial:'DEMO-'+String(10001+i),manufacturer:['SafeLine','FireGuard','Protec'][i%3],model:models[c],installedAt:'2025-04-12',lastInspection:i%4===0?'2026-09-14':'2026-10-'+String(15+(i%6)).padStart(2,'0'),nextDue:i%7===0?'2026-10-17':i%5===0?'2026-10-21':'2026-11-'+String(1+(i%26)).padStart(2,'0'),active:true,notes:'Demonstration asset. Replace with the client’s equipment details.'};
  });
  const inspections = Array.from({length:32},(_,i)=>{
    const a=assets[i],t=templates.find(x=>x.category===a.category),failed=i%8===0;
    return {id:'INS-'+String(1032-i),assetId:a.id,templateId:t.id,templateName:t.name,templateVersion:1,questions:JSON.parse(JSON.stringify(t.questions)),answers:Object.fromEntries(t.questions.map((q,j)=>[q.id,q.type==='result'?(failed&&j===3?'Fail':'Pass'):''])),notes:failed?'Visible wear requires a corrective action.':'Inspection completed. No additional observations.',photos:[],signature:null,signer:users[2+i%4].name,technicianId:users[2+i%4].id,type:i%4===0?'Service':'Inspection',date:'2026-10-'+String(20-Math.floor(i/5)).padStart(2,'0'),submittedAt:'2026-10-'+String(20-Math.floor(i/5)).padStart(2,'0')+'T'+String(8+i%8).padStart(2,'0')+':30:00',status:'Submitted',result:failed?'Attention required':'Passed'};
  });
  const defects=[
    {id:'DEF-1001',assetId:'FRS-0001',inspectionId:'INS-1032',title:'Discharge hose shows visible cracking',description:'Cracking observed near the hose coupling. Replace the hose and confirm condition.',severity:'High',status:'Open',ownerId:'u3',due:'2026-10-22',createdAt:'2026-10-20',events:[{date:'2026-10-20',by:'Sipho Dlamini',status:'Open',note:'Reported during routine inspection.'}],photos:[]},
    {id:'DEF-1002',assetId:'FRS-0009',inspectionId:'INS-1024',title:'Hydrant connection cap missing',description:'Fit a suitable replacement cap and verify connection condition.',severity:'Medium',status:'In progress',ownerId:'u4',due:'2026-10-23',createdAt:'2026-10-19',events:[{date:'2026-10-19',by:'James Petersen',status:'Open',note:'Cap missing.'},{date:'2026-10-20',by:'Thandi Mokoena',status:'In progress',note:'Replacement assigned to technician.'}],photos:[]},
    {id:'DEF-1003',assetId:'FRS-0017',inspectionId:'INS-1016',title:'Service identification is not legible',description:'Replace the identification label and record the new reference.',severity:'Low',status:'Resolved',ownerId:'u5',due:'2026-10-21',createdAt:'2026-10-18',events:[{date:'2026-10-18',by:'Naledi Khumalo',status:'Open',note:'Label illegible.'},{date:'2026-10-20',by:'Naledi Khumalo',status:'Resolved',note:'New label fitted. Awaiting manager verification.'}],photos:[]},
    {id:'DEF-1004',assetId:'FRS-0025',inspectionId:'INS-1008',title:'Mounting bracket was loose',description:'Secure the bracket and inspect fixings.',severity:'Medium',status:'Closed',ownerId:'u6',due:'2026-10-20',createdAt:'2026-10-17',events:[{date:'2026-10-17',by:'Daniel Jacobs',status:'Open',note:'Bracket loose.'},{date:'2026-10-19',by:'Daniel Jacobs',status:'Resolved',note:'Fixings secured.'},{date:'2026-10-20',by:'Thandi Mokoena',status:'Closed',note:'Repair verified.'}],photos:[]}
  ];
  return {version:1,users,customers,sites,templates,assets,inspections,defects,drafts:[],activity:[{text:'Sipho completed an inspection at Harbourview',date:'2026-10-20T15:30:00',type:'inspection'},{text:'Corrective action DEF-1003 is ready for review',date:'2026-10-20T14:15:00',type:'defect'},{text:'New assets registered at Cedar Industrial Park',date:'2026-10-20T11:20:00',type:'asset'}],settings:{company:'Fire Risk Systems',legalName:'Fire Risk Systems (Pty) Ltd',email:'service@example.test',phone:'+27 00 000 0000',address:'South Africa',footer:'Demonstration service report. Sample checklist content requires client approval.',logo:null}};
}
